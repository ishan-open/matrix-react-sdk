/*
 * skin-sdk.js
 *
 * Skins the react-sdk with the vector components
 */

const sdk = require('matrix-react-sdk');
sdk.loadSkin(require('../src/component-index'));
