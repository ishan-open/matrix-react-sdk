module.exports = {
    extends: ["./node_modules/matrix-react-sdk/.eslintrc.js"],
}
